# text_stats/__main__.py

import sys
import counter

segments = sys.argv[1:]

full_text = ' '.join(segments)

print('# words: {}, # chars: {}'.format(*counter.count(full_text)))
